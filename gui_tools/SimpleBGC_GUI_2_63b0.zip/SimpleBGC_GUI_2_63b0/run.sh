java -Dsimplebgc_gui.SimpleBGC_GUIView.Logger.level=0 -Djava.library.path="lib" -Dlog4j.configuration=log4j.properties -Dgnu.io.rxtx.NoVersionOutput=true -Djava.library.path=./lib -jar SimpleBGC_GUI.jar

